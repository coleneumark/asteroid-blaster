package Logic;

//Enum used to indicate the state of the game engine
public enum GameState {
    PLAYING,
    PAUSED
}
