package Interfaces;

//Event created for when the game is paused
public interface IOnPauseEvent {
     void onPause(); // know main stage implements IonPause so that each class has on pause
}
