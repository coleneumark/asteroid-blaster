module com.mycompany.astriods {
    requires javafx.controls;
    requires javafx.media;
    exports Application.asteroidblaster.asteroids;
    
}
