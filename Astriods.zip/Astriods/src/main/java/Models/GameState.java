package Models;

public enum GameState {
    Playing,
    Paused
}
