package Models;

public enum AsteroidSize {
    Large,
    Medium,
    Small
}
