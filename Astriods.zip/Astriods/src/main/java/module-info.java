module com.mycompany.astriods {
    requires javafx.controls;
    exports com.mycompany.astriods;
}
