module com.mycompany.astriods {
    requires javafx.controls;
    requires javafx.media;
    exports com.mycompany.astriods;
    
}
