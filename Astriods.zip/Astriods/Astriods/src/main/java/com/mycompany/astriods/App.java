package com.mycompany.astriods;
import Stages.GameOverStage;
import Stages.GameStage;
import Stages.HighScoreStage;
import Stages.MenuStage;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.stage.StageStyle;


public class App extends Application {
    private GameEngine engine;
    
    @Override
    public void start(Stage stage) throws Exception {
        //CReate the engine
        engine = GameEngine.getEngine();
        stage.initStyle(StageStyle.UNDECORATED);
        //New thread is made because the game engine will lock the main thread when it starts
        //And the main thread is teh gui thread
        Thread thread = new Thread(() -> {
            //load alll the stages
            engine.loadStage(new GameStage("GameStage"));
            engine.loadStage(new MenuStage("MainStage"));
            engine.loadStage(new GameOverStage("GameOverStage"));
            engine.loadStage(new HighScoreStage("HighScoreStage"));
            
            try {
                //set the current stage
                engine.setCurrentStage("MainStage");
                //start the game
                engine.start();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
        
        thread.start();
    }

    public static void main(String[] args) throws Exception {
        launch(args);
    }

}