package Stages;

import Interfaces.IAlienShip;
import Interfaces.IBullet;
import Logic.Asteroid;
import Interfaces.IGameObject;
import Interfaces.IPlayer;
import Interfaces.IStage;
import Interfaces.IAsteroid;
import Interfaces.IOnPauseEvent;
import Logic.AlienShip;
import Logic.AsteroidSize;
import static Logic.AsteroidSize.Medium;
import Logic.GameSettings;
import Logic.Ship;
import com.mycompany.astriods.GameEngine;
import java.util.ArrayList;
import java.util.List;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

//This stage handles the main game.
public class GameStage extends Application implements IStage, IOnPauseEvent {
    private String name;
    private ArrayList<IGameObject> gameObjects;
    private Stage stage = null;
    private Scene scene = null;
    private Pane root = null;
    private int score = 0;
    private int level = 1;
    private final GameEngine engine;
    private Ship ship;
    private GameSettings settings ;
    private List<IGameObject> bulletQueue = new ArrayList<>();
    
    public GameStage(String name){
        this.engine = GameEngine.getEngine();
        this.name = name;
    }
    
    //Bulet queue list is used to queue bullets so that the game object list
    //is not updated while getting looped
    public void addBulletToQueue(IGameObject bullet){
        this.bulletQueue.add(bullet);
    }
    
    public Ship getShip(){
       return this.ship;
    }
    
    @Override
    public String getName() {
       return this.name; 
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public ArrayList<IGameObject> getGameObjects() {
        return this.gameObjects;   
    }

    @Override
    public void setGameObject(ArrayList<IGameObject> gameObjects) {
        this.gameObjects = gameObjects;
    }

    @Override
    public void addGameObject(IGameObject object){
        this.gameObjects.add(object);
    }
    
    @Override
    public void removeGameObject(IGameObject object){
        this.gameObjects.remove(object);
    }
    
    //Check if all astroids are dead, if they are advance to the next stage
    public void checkLevelUp(){
        for(IGameObject item : this.gameObjects){
            if(IAsteroid.class.isAssignableFrom(item.getClass()) && item.getIsAlive()) {
                return;
            }
        }
        this.level++;
        for (int i = 0; i < this.level; i++) {
            Asteroid astriod = new Asteroid(AsteroidSize.Large);
            astriod.OnCreate();
            this.gameObjects.add(astriod);   
        }
                
        if(this.level % this.settings.alienShipEveryLevel == 0){
            this.gameObjects.add(new AlienShip(this.level * 3));
        }
    }
    
    @Override
    public void draw() {
        //The scene has not finished its initialization
        if(root == null) {
            return;
        }
       
        Platform.runLater(() -> {
            //Add the queued bullets to the list, this is to avoid modfiying the list as you are looping
            this.gameObjects.addAll(this.bulletQueue);
            
            //clear the queue
            this.bulletQueue =  new ArrayList<>();
            root.getChildren().clear();
            ArrayList<IGameObject> tempLst =  new ArrayList<>();
            //Here we loop though all the objects to remove any dead objects
            for(IGameObject item : this.gameObjects){
                if(item.getIsAlive()){//if the item is still alive add it to the temp list
                    tempLst.add(item);
                }else if(IAsteroid.class.isAssignableFrom(item.getClass())){
                    //recreate a smaller asteroid if Large or medium one dies
                    switch(((IAsteroid)item).getSize()){
                        case Large:
                                this.score += 10;
                                tempLst.add(new Asteroid(AsteroidSize.Medium,item.getX(),item.getY()));
                                tempLst.add(new Asteroid(AsteroidSize.Medium,item.getX(),item.getY()));
                            break;
                        case Medium:
                                this.score += 20;
                                tempLst.add(new Asteroid(AsteroidSize.Small,item.getX(),item.getY()));
                                tempLst.add(new Asteroid(AsteroidSize.Small,item.getX(),item.getY()));
                            break;
                        case Small:
                                this.score += 30;
                            break;
                    }
                }
            }
            
            //Set the game objects to the temp list which only contains the alive objects
            this.gameObjects = tempLst;
            //after all dead objects have been removed, check if there are any objects left on this level
            checkLevelUp();
            
            //loop throgh all the game objects and call thier update function
            for(IGameObject item : this.gameObjects){
                item.update();
                
                //The polygon of the item to the root
                Polygon object = item.getPolygon();
                root.getChildren().add(object);
              
                //Logic should only execute on none player classes
                if(!IPlayer.class.isAssignableFrom(item.getClass())){
                    //If the item is a bullet scan all the astriods
                    if(IBullet.class.isAssignableFrom(item.getClass())){
                        //Check if this is a alien ship bullet, if it is check if the player ship has colided with it
                       if(!((IBullet)item).getIsIsPlayerBullet()){
                           //Check if the alien ship has shot the player ship
                           if(ship.hasCollided(item)){
                               ship.subtractLife();
                               if(ship.getLives() == 0){
                                    try {
                                        this.gameOver();
                                        return;//return out of this current loop not to show the stage.
                                    } catch (Exception ex) {
                                    }
                                }
                           }
                        }else{
                           //Check if any of the npc's (astroid/alien ship) has collided with the bullets from the player ship
                            for(IGameObject npc : this.gameObjects){
                                if(IAsteroid.class.isAssignableFrom(npc.getClass()) || IAlienShip.class.isAssignableFrom(npc.getClass())){
                                    if(item.hasCollided(npc)){
                                        npc.hasCollided(item);
                                    }
                                }
                            }
                        }
                        
                    }
                    
                    if(!IBullet.class.isAssignableFrom(item.getClass()) && ship.hasCollided(item)){
                        ship.subtractLife();
                        if(ship.getLives() == 0){
                            try {
                                this.gameOver();
                                return;
                            } catch (Exception ex) {
                            }
                        }
                    }
                }
            }
            Text lives = new Text("LIVES: " + ship.getLives());
            Text level = new Text("level: " + this.level);
            level.setFill(Color.WHITE);
            lives.setFill(Color.WHITE);
            lives.setFont(new Font("Arial", 20));
            level.setFont(new Font("Arial", 20));
            lives.setX(scene.getWidth() - 100);
            lives.setY(20);
            Text score = new Text("Score: " + this.score);
            score.setFill(Color.WHITE);
            score.setFont(new Font("Arial", 20));
            score.setX(20);
            score.setY(40);
            level.setX(20);
            level.setY(20);
            root.getChildren().add(score);
            root.getChildren().add(lives);
            root.getChildren().add(level);

            root.setStyle("-fx-background-color: black;");
            Rectangle2D screenBounds = Screen.getPrimary().getVisualBounds();

            double centerX = (screenBounds.getWidth() - scene.getWidth()) / 2;
            double centerY = (screenBounds.getHeight() - scene.getHeight()) / 2;

            stage.setX(centerX);
            stage.setY(centerY);
            stage.setScene(scene);
            if(ship.getLives() != 0){
                stage.show();
            }
        });
    }

    @Override
    public void loadStage() {
        this.score = 0;
        this.level = 1;
        this.gameObjects = new ArrayList<>();
        for (int i = 0; i < this.level; i++) {
            this.gameObjects.add(new Asteroid(AsteroidSize.Large)); 
        }
        
        this.settings = GameSettings.GetInstince();
 
        if((this.level % this.settings.alienShipEveryLevel) == 0){
            this.gameObjects.add(new AlienShip(this.level * 3));
        }
        this.ship = new Ship();
        this.gameObjects.add(ship);

        Platform.runLater(() -> {
            this.stage = new Stage();
            this.stage.initStyle(StageStyle.UNDECORATED);
            this.root = new Pane();
            this.scene = new Scene(root, settings.boardWidth,settings.boardHeight);
            this.ship.OnCreate();
            this.stage.setX(0);
            this.stage.setY(0);
            this.scene.setOnKeyPressed((event) -> {
                this.engine.handleKeyPress(event.getCode());
                this.ship.handleKeyPress(event.getCode());
             });
            
            this.scene.setOnKeyReleased((event) ->{
                if(event.getCode() == KeyCode.SPACE){
                    this.ship.shoot();
                }
            } );
          
            for(IGameObject item : this.gameObjects){
                item.OnCreate();
            }
            this.engine.addOnPauseEvent(this);
            this.draw();
        });
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        this.loadStage();
    }

    @Override
    public void hide() {
        this.stage.hide();
    }

    //open the score screen if the game is over
    private void gameOver() throws Exception {
      this.engine.setScore(score);
      this.engine.setCurrentStage("GameOverStage");
    }

    //Popup if the game is paused
    @Override
    public void onPause() {
    Platform.runLater(() -> {
        Stage popup = new Stage();
        popup.initStyle(StageStyle.UNDECORATED);
        popup.initOwner(stage);
        popup.initModality(Modality.APPLICATION_MODAL);

        VBox container = new VBox(10);
        container.setAlignment(Pos.CENTER);
        container.setPrefSize(250, 100);
        container.setStyle("-fx-background-color: #f2f2f2; -fx-border-color: grey; -fx-border-width: 2;");
        Label resumeLabel = new Label("Resume");
        Label quitLabel = new Label("Quit");

        resumeLabel.setOnMouseClicked(e -> {
                    popup.close();
                    this.engine.resumeGame();
                });
        quitLabel.setOnMouseClicked(e -> {
            popup.close();
            this.engine.resumeGame();
            try {
                this.engine.setCurrentStage("MainStage");
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        container.getChildren().addAll(resumeLabel, quitLabel);
        Scene popupScene = new Scene(container);
        popup.setScene(popupScene);
        popup.show();
    });




    }
}
