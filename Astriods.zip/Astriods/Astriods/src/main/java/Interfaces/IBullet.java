package Interfaces;

//Interface to identify a bullet
public interface IBullet {
    //function that check if the current bullet source is from the player
    boolean getIsIsPlayerBullet();
    
    //function to set teh source of this bullet
    void setIsPlayerBullet(boolean isPlayerBullet);
}
