package Interfaces;

//Event created for when the game is paused
public interface IOnPauseEvent {
     void onPause();
}
