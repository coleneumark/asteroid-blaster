
package Interfaces;

import Logic.AsteroidSize;

//Interface to idnetfy a astroid 
public interface IAsteroid {
    //function to return the size of an astriod
    public AsteroidSize getSize();
}
