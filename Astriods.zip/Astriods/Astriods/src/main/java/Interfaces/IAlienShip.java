package Interfaces;

//Interface used to identify the alien ship
public interface IAlienShip {
    //Alien ship has it's own shoot function
    void shoot();
}
