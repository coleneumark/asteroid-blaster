package Logic;

//Enum used to indecate the state of the game engine
public enum GameState {
    Playing,
    Paused
}
