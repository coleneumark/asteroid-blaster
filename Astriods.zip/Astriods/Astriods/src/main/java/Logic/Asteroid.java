package Logic;

import Interfaces.IGameObject;
import Interfaces.IAsteroid;
import Interfaces.IBullet;
import static Logic.AsteroidSize.Medium;
import java.util.Random;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;

//An astroid has 3 sizes, based on the size the speed 
//will be changed
public class Asteroid implements IGameObject, IAsteroid {
    private int x;
    private int y;
    private Random rnd = new Random();
    private Polygon polygon;
    private int currentXDestination;
    private int currentYDestination;
    private GameSettings settings = new GameSettings();
    private AsteroidSize size = AsteroidSize.Large;
    private boolean isAlive = true;
    private int speed;
    
    public Asteroid(AsteroidSize size){
        this.size = size;
        this.x = rnd.nextInt(settings.boardHeight)-60; 
        this.y = rnd.nextInt(settings.boardWidth)-60;
        settings = GameSettings.GetInstince();
    }
    
    //Since the astroids will be recreated a lot of times the on create function
    // is call in the constructor
    public Asteroid(AsteroidSize size,int x, int y){
        this.size = size;
        this.x = x;
        this.y = y;
        settings = GameSettings.GetInstince();
        this.OnCreate();
    }
    
    //Returns the size of the astroid
    @Override
    public AsteroidSize getSize(){
        return this.size;
    }
    
    //creates the polygons for the astroid
    private Polygon createAstriod(double x, double y, AsteroidSize asteriodSize) {
        int size = 0;
        switch (asteriodSize) {
            case Large: size = 100;
                break;
            case Medium: size = 70;
                break;
            case Small: size = 30;
                break;
        }
        Polygon shape = new Polygon();
        double[] points = { x + size * 0.1, y + size * 0.5,
                        x + size * 0.3, y + size * 0.2,
                        x + size * 0.8, y + size * 0.3,
                        x + size * 0.9, y + size * 0.7,
                        x + size * 0.5, y + size * 0.9,
                        x + size * 0.1, y + size * 0.7 };
         for (double point : points) {
            shape.getPoints().add(point);
        }
       
        shape.setStroke(Color.WHITE);
        shape.setStrokeWidth(2.0);
        return shape;
    }
    
    @Override
    public void OnCreate() {
        this.setRandomDestination();
        int upperbound = 0;
        int lowerbound = 0;
        
        //Set the lower and upper bound of the astroid which 
        //is used to random it's speed
        switch(this.size){
            case Large:
                lowerbound =1;
                upperbound = 3;
                break;
            case Medium:
                lowerbound = 3;
                upperbound = 6;
                break;
            case Small:
                lowerbound = 5;
                upperbound = 7;
                break;
        }
        
        //Random the speed based on the bounds.
        this.speed =  rnd.nextInt(upperbound-lowerbound) + lowerbound;
    }
    
    //Set a random destination on the stage for the astroid to move to
    private void setRandomDestination(){
        this.currentXDestination = rnd.nextInt(settings.boardHeight)-60;        
        this.currentYDestination = rnd.nextInt(settings.boardWidth)-60;        
    }

    @Override
    public void update() {
        
        //If the astroid is more or less 10 units within it's target generate a new destination
        if((Math.abs(this.x - this.currentXDestination) < 10) && (Math.abs(this.y - this.currentYDestination) < 10)) {
            setRandomDestination();
        }
        
        //move x
        if(this.x != this.currentXDestination){
            if(this.x < this.currentXDestination){
                this.x+= speed;
            }else{
                this.x-= speed;
            }
        }
        //Move y
        if(this.y != this.currentYDestination){
            if(this.y < this.currentYDestination){
                this.y += speed;
            }else{
                this.y -= speed;
            }
        }
        this.polygon = createAstriod(x,y,this.size);
    }
    
    
    @Override
    public int getY() {
        return this.y;
    }

    @Override
    public int getX() {
        return this.x;
    }

    @Override
    public Polygon getPolygon() {
        return polygon;
    }

    @Override
    public double getSpeed() {
       return this.speed;
    }
    
    //If the astroid colides with a player bullet it should die
    @Override
    public boolean hasCollided(IGameObject object) {
        //check if the game object is a bullet. This is done by checking 
        //if the game object implements the IBullet interface
        if (object instanceof IBullet){
            //cast the game object to a bullet 
            IBullet bullet = (IBullet) object;
            //Check if this bullet is a player bulelt
            if(bullet.getIsIsPlayerBullet()){
                this.isAlive = false;
            }
        }
        return false;
    }

    @Override
    public boolean getIsAlive() {
          return this.isAlive;
    }

}