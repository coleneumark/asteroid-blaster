package Logic;

//Enum used to indecate the size of an asteroid
public enum AsteroidSize {
    Large,
    Medium,
    Small
}
