package Logic;

//Enum used to indicate the size of an asteroid
public enum AsteroidSize {
    LARGE,
    MEDIUM,
    SMALL
}
