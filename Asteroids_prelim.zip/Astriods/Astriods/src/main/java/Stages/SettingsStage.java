package Stages;

import Interfaces.IGameObject;
import Interfaces.IStage;
import Logic.GameSettings;
import com.mycompany.astriods.GameEngine;
import java.util.ArrayList;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class SettingsStage implements IStage{
    private String name;
    private Stage stage;
    private Scene scene;
    private Pane root;
    private int score = 0;
    private GameEngine engine;
    public static MenuStage instance;
    private GameSettings settings ;
    
    public SettingsStage(String name){
        this.engine = GameEngine.getEngine();
        this.settings = GameSettings.GetInstince();
        this.name = name;
    }
    
    @Override
    public String getName() {
       return this.name; 
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public void draw() {
        
    }
       

    @Override
    public void loadStage() {

        Platform.runLater(() -> {
            this.stage = new Stage();
            this.root = new Pane();
            this.scene = new Scene(root, settings.boardWidth,settings.boardHeight);
            Button backButton = new Button("Back");      

            backButton.setOnAction(event -> {
                try {
                    engine.setCurrentStage("MainStage");// Navigate back to the main menu
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            });
            // Set the font and alignment of the labels

            this.stage.initStyle(StageStyle.UNDECORATED);
            root.getChildren().addAll(backButton);
            root.setCenterShape(true);
            
            Label textFieldHeightLabel = new Label("Height");            
            textFieldHeightLabel.setAlignment(Pos.CENTER);
            
            Label textFieldWidthLabel = new Label("Width");
            textFieldWidthLabel.setAlignment(Pos.CENTER);
            
            TextField textFieldHeight = new TextField(String.valueOf( settings.boardHeight));
             textFieldHeight.setAlignment(Pos.CENTER);
             
            TextField textFieldWidth = new TextField(String.valueOf( settings.boardWidth));
            textFieldWidth.setAlignment(Pos.CENTER);
                    
            textFieldWidth.setTextFormatter(new TextFormatter<>(change -> {
                String newText = change.getControlNewText();
                if (newText.matches("\\d*")) {
                    return change;
                } else {
                    return null;
                }}));
            
            textFieldHeight.setTextFormatter(new TextFormatter<>(change -> {
                String newText = change.getControlNewText();
                if (newText.matches("\\d*")) {
                    return change;
                } else {
                    return null;
            }}));
            
            Rectangle2D screenBounds = Screen.getPrimary().getVisualBounds();
            double centerX = (screenBounds.getWidth() - scene.getWidth()) / 2;
            double centerY = (screenBounds.getHeight() - scene.getHeight()) / 2;
                
            // Set the layout of the labels and text fields

            textFieldHeightLabel.setLayoutY(100);
            textFieldHeightLabel.setLayoutX(20);
            textFieldWidthLabel.setLayoutY(150);
            textFieldWidthLabel.setLayoutX(20);
            textFieldHeight.setLayoutX(100);
            textFieldHeight.setLayoutY(100);
            
            textFieldWidth.setLayoutX(100);
            textFieldWidth.setLayoutY(150);
            
            Button submitButton = new Button("Submit");
            submitButton.setLayoutX(100);
            submitButton.setLayoutY(200);
             submitButton.setOnAction(event -> {
                int height = Integer.parseInt(textFieldHeight.getText());
                int width = Integer.parseInt(textFieldWidth.getText());
                settings.boardHeight = height;
                settings.boardWidth = width;
                try {
                    this.engine.setCurrentStage("MainStage");
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            });
            submitButton.setAlignment(Pos.CENTER);
            root.getChildren().addAll(textFieldHeightLabel, textFieldHeight,textFieldWidthLabel, textFieldWidth,submitButton);

            stage.setX(centerX);
            stage.setY(centerY);
            stage.setScene(scene);
            this.stage.show();
        });
    }
      

    
    public void start(Stage primaryStage) throws Exception {
        this.loadStage();
    }

    @Override
    public ArrayList<IGameObject> getGameObjects() {
        throw new UnsupportedOperationException("Scene does not contain game objects");
    }

    @Override
    public void setGameObject(ArrayList<IGameObject> gameObjects) {
        throw new UnsupportedOperationException("Scene does not contain game objects");
    }

    @Override
    public void addGameObject(IGameObject object) {
        throw new UnsupportedOperationException("Scene does not contain game objects");
    }

    @Override
    public void removeGameObject(IGameObject object) {
        throw new UnsupportedOperationException("Scene does not contain game objects"); 
    }
    
    @Override
    public void hide() {
        this.stage.hide();
    }
}
