package Stages;

import Interfaces.IGameObject;
import Interfaces.IStage;
import Logic.GameSettings;
import com.mycompany.astriods.GameEngine;
import java.util.ArrayList;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class MenuStage implements IStage{
 private String name;
    private Stage stage;
    private Scene scene;
    private Pane root;
    private int score = 0;
    private GameEngine engine;
    public static MenuStage instance;
    private GameSettings settings ;
    
    public MenuStage(String name){
        this.engine = GameEngine.getEngine();
        this.settings = GameSettings.GetInstince();
        this.name = name;
    }
    
    @Override
    public String getName() {
       return this.name; 
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public void draw() {
        
    }

    @Override
    public void loadStage() {
        Platform.runLater(() -> {
            this.stage = new Stage();
            this.root = new Pane();
            this.scene = new Scene(root, settings.boardWidth,settings.boardHeight);
            
            Label playLabel = new Label("Play");
            Label highscoreLabel = new Label("Highscore");
            Label quitLabel = new Label("Quit");
            Label settingsLabel = new Label("Settings");
            root.setStyle("-fx-background-color: black;");
            playLabel.setTextFill(Color.WHITE);
            quitLabel.setTextFill(Color.WHITE);
            settingsLabel.setTextFill(Color.WHITE);
            highscoreLabel.setTextFill(Color.WHITE);
            
            quitLabel.setOnMouseClicked(event -> {
                // code to be executed when label is clicked
                System.exit(0);
             });
            
            highscoreLabel.setOnMouseClicked(event -> {
                try {
                    // code to be executed when label is clicked
                    engine.setCurrentStage("HighScoreStage");
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
             });
            
            playLabel.setOnMouseClicked(event -> {
                try {
                    // code to be executed when label is clicked
                    engine.setCurrentStage("GameStage");
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
             });
            
            settingsLabel.setOnMouseClicked(event -> {
                try {
                    // code to be executed when label is clicked
                    engine.setCurrentStage("SettingsStage");
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
             });
            
// Set the font and alignment of the labels
            playLabel.setFont(new Font(36));
            settingsLabel.setFont(new Font(36));
            highscoreLabel.setFont(new Font(36));
            quitLabel.setFont(new Font(36));
            
            playLabel.setAlignment(Pos.CENTER);
            highscoreLabel.setAlignment(Pos.CENTER);
            quitLabel.setAlignment(Pos.CENTER);
            settingsLabel.setAlignment(Pos.CENTER);

            this.stage.initStyle(StageStyle.UNDECORATED);
            // Add the labels to the root pane and position them in the center
            root.getChildren().addAll(playLabel, highscoreLabel, quitLabel, settingsLabel);
            root.setCenterShape(true);

            playLabel.layoutXProperty().bind(root.widthProperty().divide(2).subtract(playLabel.widthProperty().divide(2)));
            highscoreLabel.layoutXProperty().bind(root.widthProperty().divide(2).subtract(highscoreLabel.widthProperty().divide(2)));
            quitLabel.layoutXProperty().bind(root.widthProperty().divide(2).subtract(quitLabel.widthProperty().divide(2)));        
            settingsLabel.layoutXProperty().bind(root.widthProperty().divide(2).subtract(settingsLabel.widthProperty().divide(2)));

            playLabel.layoutYProperty().bind(root.heightProperty().divide(2).subtract(playLabel.heightProperty().multiply(1.5)));
            highscoreLabel.layoutYProperty().bind(root.heightProperty().divide(2).subtract(highscoreLabel.heightProperty().multiply(0.5)));
            quitLabel.layoutYProperty().bind(root.heightProperty().divide(2).add(quitLabel.heightProperty().multiply(1.5)));
            settingsLabel.layoutYProperty().bind(root.heightProperty().divide(2).add(settingsLabel.heightProperty().multiply(0.5)));

            Rectangle2D screenBounds = Screen.getPrimary().getVisualBounds();
            double centerX = (screenBounds.getWidth() - scene.getWidth()) / 2;
            double centerY = (screenBounds.getHeight() - scene.getHeight()) / 2;

            stage.setX(centerX);
            stage.setY(centerY);
            stage.setScene(scene);
            this.stage.show();
        });
    }
      

    
    public void start(Stage primaryStage) throws Exception {
        this.loadStage();
    }

    @Override
    public ArrayList<IGameObject> getGameObjects() {
        throw new UnsupportedOperationException("Scene does not contain game objects");
    }

    @Override
    public void setGameObject(ArrayList<IGameObject> gameObjects) {
        throw new UnsupportedOperationException("Scene does not contain game objects");
    }

    @Override
    public void addGameObject(IGameObject object) {
        throw new UnsupportedOperationException("Scene does not contain game objects");
    }

    @Override
    public void removeGameObject(IGameObject object) {
        throw new UnsupportedOperationException("Scene does not contain game objects"); 
    }
    
    @Override
    public void hide() {
        this.stage.hide();
    }
}
