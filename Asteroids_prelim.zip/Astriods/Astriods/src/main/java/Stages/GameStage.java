package Stages;

import Interfaces.IBullet;
import Logic.Asteroid;
import Interfaces.IGameObject;
import Interfaces.IPlayer;
import Interfaces.IStage;
import Interfaces.IAsteroid;
import Logic.AsteroidSize;
import static Logic.AsteroidSize.Medium;
import Logic.GameSettings;
import Logic.Ship;
import com.mycompany.astriods.GameEngine;
import java.util.ArrayList;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Polygon;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;


public class GameStage extends Application implements IStage {
    private String name;
    private ArrayList<IGameObject> gameObjects;
    private Stage stage = null;
    private Scene scene = null;
    private Pane root = null;
    private int score = 0;
    private int level = 1;
    private GameEngine engine;
    
    Ship ship;
    private GameSettings settings ;
    public GameStage(String name){
        this.engine = GameEngine.getEngine();
        this.name = name;
    }
    
    @Override
    public String getName() {
       return this.name; 
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public ArrayList<IGameObject> getGameObjects() {
        return this.gameObjects;   
    }

    @Override
    public void setGameObject(ArrayList<IGameObject> gameObjects) {
        this.gameObjects = gameObjects;
    }

    @Override
    public void addGameObject(IGameObject object){
        this.gameObjects.add(object);
    }
    
    @Override
    public void removeGameObject(IGameObject object){
        this.gameObjects.remove(object);
    }
    
    public void checkLevelUp(){
        for(IGameObject item : this.gameObjects){
            if(IAsteroid.class.isAssignableFrom(item.getClass()) && item.getIsAlive()) {
                return;
            }
        }
        this.level++;
        for (int i = 0; i < this.level; i++) {
            Asteroid astriod = new Asteroid(AsteroidSize.Large);
            astriod.OnCreate();
            this.gameObjects.add(astriod);   
        }
    }
    
    @Override
    public void draw() {
        Platform.runLater(() -> {
            root.getChildren().clear();
            ArrayList<IGameObject> tempLst =  new ArrayList<>();
            for(IGameObject item : this.gameObjects){
                if(item.getIsAlive()){
                    tempLst.add(item);
                }else if(IAsteroid.class.isAssignableFrom(item.getClass())){
                    switch(((IAsteroid)item).getSize()){
                        case Large:
                                this.score += 10;
                                tempLst.add(new Asteroid(AsteroidSize.Medium,item.getX(),item.getY()));
                                tempLst.add(new Asteroid(AsteroidSize.Medium,item.getX(),item.getY()));
                            break;
                        case Medium:
                                this.score += 20;
                                tempLst.add(new Asteroid(AsteroidSize.Small,item.getX(),item.getY()));
                                tempLst.add(new Asteroid(AsteroidSize.Small,item.getX(),item.getY()));
                            break;
                        case Small:
                                this.score += 30;
                            break;
                    }
                }
            }

            this.gameObjects = tempLst;
            checkLevelUp();
            for(IGameObject item : this.gameObjects){
                item.update();
                Polygon object = item.getPolygon();
                root.getChildren().add(object);
              
               //Logic should only execute on none player classes
                if(!IPlayer.class.isAssignableFrom(item.getClass())){
                    //If the item is a bullet scan all the astriods
                    if(IBullet.class.isAssignableFrom(item.getClass())){
                        for(IGameObject astriod : this.gameObjects){
                            if(IAsteroid.class.isAssignableFrom(astriod.getClass())){
                                if(item.hasCollided(astriod)){
                                    
                                    astriod.hasCollided(item);
                                }
                            }
                        }
                    }
                    
                    if(!IBullet.class.isAssignableFrom(item.getClass()) && ship.hasCollided(item)){
                        ship.subtractLive();
                        if(ship.getLives() == 0){
                            try {
                                this.gameOver();
                                return;
                            } catch (Exception ex) {
                            }
                        }
                    }
                }
            }
            Text lives = new Text("LIVES: " + ship.getLives());
            Text level = new Text("level: " + this.level);
            level.setFill(Color.WHITE);
            lives.setFill(Color.WHITE);
            lives.setFont(new Font("Arial", 20));
            level.setFont(new Font("Arial", 20));
            lives.setX(scene.getWidth() - 100);
            lives.setY(20);
            Text score = new Text("Score: " + this.score);
            score.setFill(Color.WHITE);
            score.setFont(new Font("Arial", 20));
            score.setX(20);
            score.setY(40);
            level.setX(20);
            level.setY(20);
            root.getChildren().add(score);
            root.getChildren().add(lives);
            root.getChildren().add(level);

            root.setStyle("-fx-background-color: black;");
            Rectangle2D screenBounds = Screen.getPrimary().getVisualBounds();

            double centerX = (screenBounds.getWidth() - scene.getWidth()) / 2;
            double centerY = (screenBounds.getHeight() - scene.getHeight()) / 2;

            stage.setX(centerX);
            stage.setY(centerY);
            stage.setScene(scene);
            stage.show();
        });
    }

    @Override
    public void loadStage() {
        this.score = 0;
        this.level = 1;
        this.gameObjects = new ArrayList<>();
        for (int i = 0; i < this.level; i++) {
            this.gameObjects.add(new Asteroid(AsteroidSize.Large));   
        }
        this.ship = new Ship();
        this.gameObjects.add(ship);
        this.settings = GameSettings.GetInstince();
        
        Platform.runLater(() -> {
            this.stage = new Stage();
            this.stage.initStyle(StageStyle.UNDECORATED);
            this.root = new Pane();
            this.scene = new Scene(root, settings.boardWidth,settings.boardHeight);
            this.ship.OnCreate();
            this.stage.setX(0);
            this.stage.setY(0);
            this.scene.setOnKeyPressed((event) -> {
                this.engine.handleKeyPress(event.getCode());
                this.ship.handleKeyPress(event.getCode());
             });
            this.scene.setOnKeyReleased((event) ->{
                if(event.getCode() == KeyCode.SPACE){
                    this.ship.shoot();
                }
            } );
          
            for(IGameObject item : this.gameObjects){
                item.OnCreate();
            }
            this.draw();
        });
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        this.loadStage();
    }

    @Override
    public void hide() {
        this.stage.hide();
        
    }

    private void gameOver() throws Exception {
      this.engine.setScore(score);
      this.engine.setCurrentStage("GameOverStage");
    }
}
