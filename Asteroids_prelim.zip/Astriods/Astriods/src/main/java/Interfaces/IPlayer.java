package Interfaces;

import javafx.scene.input.KeyCode;

public interface IPlayer {
    void shoot();
    public boolean hasCollided(IGameObject object);
    public void handleKeyPress(KeyCode code);
}
