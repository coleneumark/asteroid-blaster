package Interfaces;


public interface IBullet {
    
}
