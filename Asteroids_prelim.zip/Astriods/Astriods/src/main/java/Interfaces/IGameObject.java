package Interfaces;

import javafx.scene.shape.Polygon;

public interface IGameObject {
    public void OnCreate();
    public void update();
    public Polygon getPolygon();
    public int getY();
    public int getX();
    public double getSpeed();
    boolean hasCollided(IGameObject object);
    public boolean getIsAlive();
}
