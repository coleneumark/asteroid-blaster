
package Interfaces;

import Logic.AsteroidSize;

public interface IAsteroid {
     public AsteroidSize getSize();
}
