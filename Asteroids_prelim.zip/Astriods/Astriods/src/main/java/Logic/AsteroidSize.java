package Logic;

public enum AsteroidSize {
    Large,
    Medium,
    Small
}
