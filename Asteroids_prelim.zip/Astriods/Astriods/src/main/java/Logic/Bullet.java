package Logic;

import Interfaces.IBullet;
import Interfaces.IGameObject;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Shape;

public class Bullet implements IGameObject,IBullet{
    private int x;
    private int y;
    private Polygon polygon;
    private GameSettings settings;
    private double speed = 10;
    private boolean isAlive = true;
        
    public Bullet(int x,int y){
        this.x = x;
        this.y = y;
        this.polygon = new Polygon(2, -2, 2, 2, -2, 2, -2, -2);
        this.polygon.setFill(Color.GREEN);
        this.polygon.setTranslateY(this.y);
        this.polygon.setTranslateX(this.x);
        this.settings = GameSettings.GetInstince();
    }
    
    @Override
    public void OnCreate() {
    
    }

    @Override
    public void update() {
        double swiftX = Math.cos(Math.toRadians(this.polygon.getRotate()));
        double swiftY = Math.sin(Math.toRadians(this.polygon.getRotate()));
        this.polygon.setTranslateX(this.polygon.getTranslateX() + swiftX * this.speed);
        this.polygon.setTranslateY(this.polygon.getTranslateY() + swiftY * this.speed);
        this.checkIfInbound();
    }

    @Override
    public Polygon getPolygon() {
       return this.polygon;
    }

    @Override
    public int getY() {
        return this.y;
    }

    @Override
    public int getX() {
        return this.x;
    }

    @Override
    public double getSpeed() {
        return this.speed;
    }

    @Override
    public boolean hasCollided(IGameObject object) {
        Shape hitBox = Shape.intersect(this.polygon, object.getPolygon());
        boolean collided =  hitBox.getBoundsInLocal().getWidth() != -1;
        
        if(collided){
            this.isAlive = false;
        }
        return collided;
    }
    
    @Override
    public boolean getIsAlive() {
          return this.isAlive;
    }
    
    private void checkIfInbound(){
        if (this.polygon.getBoundsInParent().getCenterX() < 0 
            || this.polygon.getBoundsInParent().getCenterX() > this.settings.boardWidth
            ||this.polygon.getBoundsInParent().getCenterY() < 0
            || this.polygon.getBoundsInParent().getCenterY() > this.settings.boardHeight) {
         this.isAlive = false;
        }
    }
}