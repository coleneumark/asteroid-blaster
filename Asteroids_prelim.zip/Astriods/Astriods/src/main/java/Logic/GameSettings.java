package Logic;

public class GameSettings {
    static GameSettings settings;
    public int boardHeight = 600;
    public int boardWidth = 600;
    public final double maxSpeed = 10;    
    public final int playerStartingLives = 3;    
    public final int maxFramesPerSecond = 60;
    public final int maxBulletsPerSecond = 5;
    public final int invincibleTime = 5;
    
    public static GameSettings GetInstince(){
        if(GameSettings.settings == null){
           GameSettings.settings = new GameSettings();
        }
        return settings;
    }
}
