package Logic;

import Interfaces.IGameObject;
import Interfaces.IStage;
import Interfaces.IPlayer;
import com.mycompany.astriods.GameEngine;
import java.io.File;
import java.util.ArrayList;
import javafx.geometry.Point2D;
import javafx.scene.input.KeyCode;
import static javafx.scene.input.KeyCode.LEFT;
import static javafx.scene.input.KeyCode.RIGHT;
import static javafx.scene.input.KeyCode.UP;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Shape;
import javafx.util.Duration;


public class Ship implements IGameObject, IPlayer{
    private int x;
    private int y;
    private Polygon polygon;
    private final GameSettings settings ;
    private double speed = 5;
    private double angularVelocityX;
    private double angularVelocityY;
    Point2D anchor = new Point2D(0, 0);
    private int lives;
    private GameEngine engine;
    private IStage currentStage;
    private boolean isAlive = true;
    private long startTime = 0;    
    private long invincibletartTime = 0;
    private int bulletShot = 0;
    private boolean isInvincible = true;
    private Media media;
    public Ship(){
        this.settings = GameSettings.GetInstince();
       // Create a Media object by passing the audio file's URL or file path
        String currentDir = System.getProperty("user.dir");
        String audioFile = currentDir + "/Pew.mp3";
        this.media = new Media(new File(audioFile).toURI().toString());
        
        // Create a MediaPlayer object by passing the Media object to its constructor
      
        
      
    }
    
    public int getLives(){
        return this.lives;
    }
    
    @Override
    public double getSpeed() {
        return this.speed;
    }
    
    public void subtractLive(){
        if(this.lives != 0){
            this.lives--;
        }
        this.respawn();
    }
    
    private Polygon createShip() {
        Polygon shape = new Polygon(-10, -10, 20, 0, -10, 10);
        shape.setFill(Color.RED);
        return shape;
    }
    
    @Override
    public void OnCreate() {
        this.polygon = createShip();
        this.x = Math.round(settings.boardWidth/2);
        this.y = Math.round(settings.boardHeight/2);
        this.polygon.setTranslateY(this.y);
        this.polygon.setTranslateX(this.x);
        this.turn(270);
        this.lives = GameSettings.settings.playerStartingLives;
        this.engine = GameEngine.getEngine();
        this.currentStage = GameEngine.getEngine().getCurrentStage();
    }

    @Override
    public void update() {
        if(this.isInvincible && ((System.currentTimeMillis() - invincibletartTime) > settings.invincibleTime * 1000)){
            this.isInvincible = false;
        }  
        double swiftX = Math.cos(Math.toRadians(this.polygon.getRotate()));
        double swiftY = Math.sin(Math.toRadians(this.polygon.getRotate()));
        this.polygon.setTranslateX(this.polygon.getTranslateX() + swiftX * this.speed);
        this.polygon.setTranslateY(this.polygon.getTranslateY() + swiftY * this.speed);
        this.checkIfInbound();
    }

    @Override
    public int getY() {
        return this.y;
    }

    @Override
    public int getX() {
        return this.x;
    }

    @Override
    public Polygon getPolygon() {
        return this.polygon;
    }
    
    public double getRotateX() { 
        return Math.cos(Math.toRadians(this.polygon.getRotate())); 
    }
    
    public double getRotateY() { 
        return Math.sin(Math.toRadians(this.polygon.getRotate())); 
    }
    
    public void turn(int angle) { 
        this.polygon.setRotate(this.polygon.getRotate() + angle); 
    }
    
    private Point2D calculateNewPosition() {
        angularVelocityX = getRotateX() * 0.01;
        angularVelocityY = getRotateY() * 0.01;
        return new Point2D(angularVelocityX, angularVelocityY);
    }
    
    @Override
    public void handleKeyPress(KeyCode code) {
        if(this.engine.getGameState() == GameState.Playing){
                switch (code) {
                    case UP:
                        Point2D speedPosition = calculateNewPosition();
                        if (getSpeed() <= settings.maxSpeed) {
                        this.speed+=.2;
                        anchor = anchor.add(speedPosition);
                    } else {
                        anchor = anchor.subtract(speedPosition).normalize().multiply(settings.maxSpeed);
                    }
                    break;
                case LEFT:
                    this.turn(-10);
                    break;
                case RIGHT:
                    this.turn(10);
                    break;
                case DOWN:
                    speedPosition = calculateNewPosition();
                    if (getSpeed() >= 0) {
                        this.speed-=.2;
                        anchor = anchor.add(speedPosition);
                    }
                    break;
            }
        }
    }
    
    private void checkIfInbound(){
        if (this.polygon.getBoundsInParent().getCenterX() < 0) {
            this.polygon.setTranslateX(this.polygon.getTranslateX() + this.settings.boardWidth);
        }

        if (this.polygon.getBoundsInParent().getCenterX() > this.settings.boardWidth) {
            this.polygon.setTranslateX(this.polygon.getTranslateX() % this.settings.boardWidth);
        }

        if (this.polygon.getBoundsInParent().getCenterY() < 0) {
            this.polygon.setTranslateY(this.polygon.getTranslateY() + this.settings.boardHeight);
        }

        if (this.polygon.getBoundsInParent().getCenterY() > this.settings.boardHeight) {
            this.polygon.setTranslateY(this.polygon.getTranslateY() % this.settings.boardHeight);
        }
    }

    @Override
    public void shoot() {
     
        if(startTime == 0){
            this.startTime = System.currentTimeMillis();
        }
        if((System.currentTimeMillis() - startTime) > 1000){
            this.bulletShot = 0;
            this.startTime = System.currentTimeMillis();
        }    
        if(bulletShot < settings.maxBulletsPerSecond){
            MediaPlayer mediaPlayer  = new MediaPlayer(media);
            // Play the audio clip
            mediaPlayer.seek(Duration.ZERO);
            mediaPlayer.play();

            Bullet bullet = new Bullet((int)this.polygon.getBoundsInParent().getCenterX(), (int)this.polygon.getBoundsInParent().getCenterY());
            bullet.getPolygon().setRotate(getPolygon().getRotate());
            // Add bullet to the array in ship class.
            this.currentStage.addGameObject(bullet);
            this.bulletShot++;
        }
    }

    @Override
    public boolean hasCollided(IGameObject object){
        if(this.isInvincible){
           return false; 
        }
        Shape hitBox = Shape.intersect(this.polygon, object.getPolygon());
        boolean collided = hitBox.getBoundsInLocal().getWidth() != -1;
        return collided;
    }
    
    @Override
    public boolean getIsAlive() {
        return this.isAlive;
    }
        
    private void respawn(){
        this.isInvincible = true;
        this.invincibletartTime = System.currentTimeMillis();
        anchor = new Point2D(0, 0);
        this.getPolygon().setTranslateX(x);
        this.getPolygon().setTranslateY(y);
        this.getPolygon().setRotate(270);
    }
}
