package Logic;

import Interfaces.IGameObject;
import Interfaces.IStage;
import Interfaces.IAsteroid;
import static Logic.AsteroidSize.Medium;
import com.mycompany.astriods.GameEngine;
import java.util.Random;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;

public class Asteroid implements IGameObject, IAsteroid {
    private int x;
    private int y;
    private Random rnd = new Random();
    private Polygon polygon;
    private int currentXDestination;
    private int currentYDestination;
    private GameSettings settings = new GameSettings();
    private AsteroidSize size = AsteroidSize.Large;
    private IStage currentStage;
    private GameEngine engine;
    private boolean isAlive = true;
    private int speed;
    public Asteroid(AsteroidSize size){
        this.size = size;
        this.x = rnd.nextInt(settings.boardHeight)-60; 
        this.y = rnd.nextInt(settings.boardWidth)-60;
        settings = GameSettings.GetInstince();
    }
    
    public Asteroid(AsteroidSize size,int x, int y){
        this.size = size;
        this.x = x;
        this.y = y;
        settings = GameSettings.GetInstince();
        this.OnCreate();
    }
    
    
    @Override
    public AsteroidSize getSize(){
        return this.size;
    }
    
    private Polygon createAstriod(double x, double y, AsteroidSize asteriodSize) {
        int size = 0;
        switch (asteriodSize) {
            case Large: size = 100;
                break;
            case Medium: size = 50;
                break;
            case Small: size = 20;
                break;
        }
        Polygon shape = new Polygon();
        double[] points = { x + size * 0.1, y + size * 0.5,
                        x + size * 0.3, y + size * 0.2,
                        x + size * 0.8, y + size * 0.3,
                        x + size * 0.9, y + size * 0.7,
                        x + size * 0.5, y + size * 0.9,
                        x + size * 0.1, y + size * 0.7 };
         for (double point : points) {
            shape.getPoints().add(point);
        }
       
        shape.setFill(Color.GREY);
        return shape;
    }
    
    @Override
    public void OnCreate() {
        this.setRandomDestination();
        int upperbound = 0;
        int lowerbound = 0;

       
        switch(this.size){
            case Large:
                lowerbound =1;
                upperbound = 3;
                break;
            case Medium:
                lowerbound = 3;
                upperbound = 6;
                break;
            case Small:
                lowerbound = 6;
                upperbound = 8;
                break;
        }
        
        this.speed =  rnd.nextInt(upperbound-lowerbound) + lowerbound;
        this.engine = GameEngine.getEngine();
        this.currentStage = GameEngine.getEngine().getCurrentStage();
    }
    
    private void setRandomDestination(){
        this.currentXDestination = rnd.nextInt(settings.boardHeight)-60;        
        this.currentYDestination = rnd.nextInt(settings.boardWidth)-60;        
    }

    @Override
    public void update() {
        if((Math.abs(this.x - this.currentXDestination) < 10) && (Math.abs(this.y - this.currentYDestination) < 10)) {
            setRandomDestination();
        }
        
        //move x
        if(this.x != this.currentXDestination){
            if(this.x < this.currentXDestination){
                this.x+= speed;
            }else{
                this.x-= speed;
            }
        }
        //Move y
        if(this.y != this.currentYDestination){
            if(this.y < this.currentYDestination){
                this.y += speed;
            }else{
                this.y -= speed;
            }
        }
        this.polygon = createAstriod(x,y,this.size);
    }

    @Override
    public int getY() {
        return this.y;
    }

    @Override
    public int getX() {
        return this.x;
    }

    @Override
    public Polygon getPolygon() {
        return polygon;
    }

    @Override
    public double getSpeed() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void destroy(){
        this.isAlive = false;
    }
    
    @Override
    public boolean hasCollided(IGameObject object) {
        this.isAlive = false;
        return true;
    }

    @Override
    public boolean getIsAlive() {
          return this.isAlive;
    }

}