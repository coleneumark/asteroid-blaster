package Logic;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ScoreHandler {
    private final String filename = "high_score.txt";
    
    public void addScore(Score playerScore) throws IOException{
        this.createIfNotExists();
        List<Score> scores = new ArrayList<>();
        List<Score> top10 =  this.readScores();
        
        //If the score is empty add it
        if(top10.isEmpty()){
            scores.add(playerScore);
            this.writeScores(scores);
        }else{
            //Check to ensure the score is only added once
            boolean added = false;
            for(Score item :top10){
                //If 10 records has been added write the file and return
                if(scores.size() == 10){
                    System.out.println("10 reached");
                    this.writeScores(scores);
                    return;
                }
                if(!added && item.getScore() < playerScore.getScore()){
                      System.out.println("Addind player score 1");
                    added = true;
                    scores.add(playerScore);
                    if(scores.size() != 10){
                        scores.add(item);
                    }
                }else{
                    scores.add(item);
                }
            }
            if(!added && scores.size() !=  10){
                System.out.println("Addind player score 2");
                scores.add(playerScore);
                added = true;
            }
            if(added){
                this.writeScores(scores);
            }
        }
    }
    
    private void createIfNotExists() throws IOException{
        File file = new File(filename);
        file.createNewFile();
    }
    
    private void writeScores(List<Score> scores) throws IOException {
        FileWriter writer = new FileWriter(filename);
        writer.write(""); // Clear file content
        for (Score score : scores) {
            writer.write(score.getName() + "|" + score.getScore() + "\n");
        }
        writer.close();
    }
    
    public  List<Score> readScores() {
        List<Score> scores = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(this.filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("[|]");
                String name = parts[0];
                int score = Integer.parseInt(parts[1]);
                scores.add(new Score(score, name));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return scores;
    }

    
}
