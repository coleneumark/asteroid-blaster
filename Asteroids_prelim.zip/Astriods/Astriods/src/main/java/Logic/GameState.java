package Logic;

public enum GameState {
    Playing,
    Paused
}
