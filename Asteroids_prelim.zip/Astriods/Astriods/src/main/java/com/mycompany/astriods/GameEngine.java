package com.mycompany.astriods;
import Logic.GameSettings;
import Logic.GameState;
import Interfaces.IStage;
import java.util.ArrayList;
import javafx.geometry.Point2D;
import javafx.scene.input.KeyCode;
import static javafx.scene.input.KeyCode.DOWN;
import static javafx.scene.input.KeyCode.LEFT;
import static javafx.scene.input.KeyCode.RIGHT;
import static javafx.scene.input.KeyCode.SPACE;
import static javafx.scene.input.KeyCode.UP;

public class GameEngine {
    private GameState state;
    private int fps = 0;
    public ArrayList<IStage> stages = new ArrayList<IStage>();
    private int currentStage = -1;
    public static GameEngine engine;
    private GameSettings settings ;
    private int score = 0;
    
    public void setScore(int score){
        this.score = score;
    }
    
    public int getScore(){
        return this.score;
    }
    
    public GameEngine(){
        this.settings = GameSettings.GetInstince();
    }
    
    public static GameEngine getEngine(){
        if(GameEngine.engine == null){
            GameEngine.engine = new GameEngine();
        }
        return GameEngine.engine;
    }
    
    public void loadStage(IStage stage){
        this.stages.add(stage);
    }
    
    public GameState getGameState(){
        return this.state;
    }
    
    public IStage getCurrentStage(){
        return this.stages.get(currentStage);
    }
    
    public void setCurrentStage(String name) throws Exception{
        System.out.println("loading stage " + name);
        if(currentStage != -1){
            System.out.println("hiding " + getCurrentStage().getName());
            getCurrentStage().hide();
        }
        for(var x = 0; x < this.stages.size();x++){
            if(stages.get(x).getName() == null ? name == null : stages.get(x).getName().equals(name)){
                this.currentStage = x;
                this.getCurrentStage().loadStage();
                return;
            }
        }
        throw new Exception("Invalid stage name");
    }

    public void pauseGame(){
        this.state = GameState.Paused;
    }

    public void resumeGame(){
        this.state = GameState.Playing;
    }
    
    //Warning is suppressed due to needing the thread.sleep in the main game loop
    @SuppressWarnings("SleepWhileInLoop")
    public void start() throws Exception{
        this.resumeGame();
        long startTime = System.currentTimeMillis();
        while(true){
            if(state == GameState.Playing){
                if((System.currentTimeMillis() - startTime) > 1000 ){
                    System.out.println(fps);
                    fps = 0;
                    startTime = System.currentTimeMillis();
                }else{
                    ExecuteGame();
                    fps++;
                }
            }
           Thread.sleep(1000 / settings.maxFramesPerSecond);
        }
    }
    
    public void ExecuteGame(){
        stages.get(currentStage).draw();
    }
    
    public void handleKeyPress(KeyCode code) {
        switch (code) {
            case ENTER:
                if(this.state == GameState.Paused){
                    this.resumeGame();
                }else{
                    this.pauseGame();
                }
                break;
        }

    }
}
