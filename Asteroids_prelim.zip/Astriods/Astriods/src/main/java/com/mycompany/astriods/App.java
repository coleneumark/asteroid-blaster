package com.mycompany.astriods;
import Interfaces.IGameObject;
import Interfaces.IStage;
import Logic.Ship;
import Stages.GameOverStage;
import Stages.GameStage;
import Stages.HighScoreStage;
import Stages.MenuStage;
import Stages.SettingsStage;
import java.util.ArrayList;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;


public class App extends Application {
    private GameEngine engine;
    
    @Override
    public void start(Stage stage) throws Exception {
        engine = GameEngine.getEngine();
        stage.initStyle(StageStyle.UNDECORATED);
        Thread thread = new Thread(() -> {
            engine.loadStage(new GameStage("GameStage"));
            engine.loadStage(new MenuStage("MainStage"));
            engine.loadStage(new SettingsStage("SettingsStage"));            
            engine.loadStage(new GameOverStage("GameOverStage"));
            engine.loadStage(new HighScoreStage("HighScoreStage"));
            
            try {
                engine.setCurrentStage("MainStage");
                engine.start();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
        
        thread.start();
    }

    public static void main(String[] args) throws Exception {
        launch(args);
    }

}