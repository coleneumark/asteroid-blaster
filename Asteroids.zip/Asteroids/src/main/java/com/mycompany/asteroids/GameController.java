
package com.mycompany.asteroids;

import com.mycompany.asteroids.GameConstants.GameState;
import javafx.scene.Scene;
public class GameController {
    private GamePane gamePane;
    private GameState gameState;

    public GameController() {
        gamePane = new GamePane(this);
        gameState = GameState.READY;
        gamePane.drawMenu();
    }

    public void startGame() {
        gameState = GameState.PLAYING;
        gamePane.clear();
        gamePane.startGame();
    }

    public void stopGame() {
        gameState = GameState.GAME_OVER;
        gamePane.stopGame();
    }

    public Scene getScene() {
        return new Scene(gamePane, GameConstants.WINDOW_WIDTH, GameConstants.WINDOW_HEIGHT);
    }
    
    public GameState getGameState() {
        return gameState;
    }
}
