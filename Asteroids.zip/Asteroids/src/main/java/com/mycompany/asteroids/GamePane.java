package com.mycompany.asteroids;

import com.mycompany.asteroids.GameConstants.GameState;
import javafx.util.Duration;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
public class GamePane extends Pane {
    
    private Timeline gameLoop;
    private Canvas canvas;
    private GameController gameController;
    private Ship ship;
    private boolean isUpPressed;
    private boolean isLeftPressed;
    private boolean isRightPressed;
    

    public GamePane(GameController gameController) {
        this.gameController = gameController;

        // Set the background
        setBackground(new Background(new BackgroundFill(Color.BLACK, null, null)));

        // Initialize the game loop
        gameLoop = new Timeline(new KeyFrame(Duration.seconds(1.0 / 60.0), event -> {
            if (gameController.getGameState() == GameState.READY) {
                drawMenu();
            } else {
                // Update the game logic
                update();
                // Draw the game elements
                draw();
            }
        }));
        gameLoop.setCycleCount(Animation.INDEFINITE);

        // Create the canvas
        canvas = new Canvas(GameConstants.WINDOW_WIDTH, GameConstants.WINDOW_HEIGHT);
        getChildren().add(canvas);

        // Create the ship
        ship = new Ship();

        // Add keyboard input handler
          // Create the ship
        ship = new Ship();

        // Add keyboard input handler
        setOnKeyPressed(event -> {
            switch (event.getCode()) {
                case UP:
                    isUpPressed = true;
                    break;
                case LEFT:
                    isLeftPressed = true;
                    break;
                case RIGHT:
                    isRightPressed = true;
                    break;
            }
        });

        setOnKeyReleased(event -> {
            switch (event.getCode()) {
                case UP:
                    isUpPressed = false;
                    break;
                case LEFT:
                    isLeftPressed = false;
                    break;
                case RIGHT:
                    isRightPressed = false;
                    break;
            }
        });
    }

private void update() {
    // Update the ship's velocity based on keyboard input
    if (isUpPressed) {
        double dx = Math.cos(Math.toRadians(ship.getAngle())) * 2.0;
        double dy = Math.sin(Math.toRadians(ship.getAngle())) * 2.0;
        ship.setVelocity(dx, dy);
    } else {
        ship.applyFriction();
    }

    // Update the ship's angle based on keyboard input
    if (isLeftPressed) {
        ship.rotate(-5.0);
    } else if (isRightPressed) {
        ship.rotate(5.0);
    }

    // Update the ship's position based on its velocity
    ship.update();
}



 private void draw() {
    // Clear the canvas
    clear();

    // Draw the ship
    ship.draw(getGraphicsContext());
}


    public void startGame() {
        // Start the game loop
        gameLoop.play();
    }

    public void stopGame() {
        // Stop the game loop
        gameLoop.stop();
    }

    public GraphicsContext getGraphicsContext() {
        return canvas.getGraphicsContext2D();
    }

    public void clear() {
        getGraphicsContext().clearRect(0, 0, getWidth(), getHeight());
    }

    public void drawMenu() {
        clear();
        getChildren().add(new Menu());
    }
    
}
