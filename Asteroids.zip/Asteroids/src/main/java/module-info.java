module com.mycompany.asteroids {
    requires javafx.controls;
    exports com.mycompany.asteroids;
}
