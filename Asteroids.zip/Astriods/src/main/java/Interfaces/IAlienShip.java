package Interfaces;

//Interface used to identify the alien ship
public interface IAlienShip {
    //Alien ship has its own shoot function
    void shoot();
}
