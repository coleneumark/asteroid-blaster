
package Interfaces;

import Logic.AsteroidSize;

//Interface to identify an asteroid 
public interface IAsteroid {
    //function to return the size of an asteriod
    public AsteroidSize getSize();
}
